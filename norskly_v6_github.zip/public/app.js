// Norskly v6
const XP_PER_CARD = 2, XP_PER_QUIZ = 2, XP_PER_WRITE = 6, XP_PER_LISTEN = 3;
const state = {
  data: null,
  level: localStorage.getItem("norskly:level") || "A2",
  mode: "flash",
  currentUnit: null,
  deck: [],
  quiz: { items: [], idx: 0, score: 0 },
  speakIdx: 0
};

const els = {
  unitList: document.getElementById("unitList"),
  dueCount: document.getElementById("dueCount"),
  reviewAll: document.getElementById("reviewAll"),
  resetBtn: document.getElementById("resetBtn"),
  stage: document.getElementById("stage"),
  exportBtn: document.getElementById("exportBtn"),
  levelSelect: document.getElementById("levelSelect"),
  goalSelect: document.getElementById("goalSelect"),
  xpToday: document.getElementById("xpToday"),
  streak: document.getElementById("streak"),
  voiceSelect: document.getElementById("voiceSelect"),
  preloadBtn: document.getElementById("preloadBtn")
};

const settings = { voice: localStorage.getItem("norskly:voice") || "alloy" };
if (els.voiceSelect) els.voiceSelect.value = settings.voice;

fetch("./lessons.json").then(r=>r.json()).then(data=>{
  state.data = data;
  els.levelSelect.value = state.level;
  renderUnits(); updateDueCount(); updateXP();
});

els.levelSelect.addEventListener("change", ()=>{
  state.level = els.levelSelect.value;
  localStorage.setItem("norskly:level", state.level);
  renderUnits(); state.currentUnit=null;
  els.stage.innerHTML = `<div class="text-slate-600">Pick a unit for ${state.level} or open Dashboard.</div>`;
});

document.addEventListener("click", (e)=>{
  const btn = e.target.closest(".modeBtn");
  if (!btn) return;
  document.querySelectorAll(".modeBtn").forEach(x=>x.classList.remove("bg-black","text-white"));
  btn.classList.add("bg-black","text-white");
  state.mode = btn.dataset.mode;
  if (state.mode === "dashboard") return renderDashboard();
  if (state.currentUnit) startUnit(state.currentUnit.slug);
});

els.resetBtn.addEventListener("click", ()=>{
  if (!confirm("Reset all progress?")) return;
  localStorage.removeItem("norskly:leitner");
  localStorage.removeItem("norskly:stats");
  updateDueCount(); updateXP();
  if (state.mode === "dashboard") renderDashboard();
  else if (state.currentUnit) startUnit(state.currentUnit.slug);
});

els.exportBtn.addEventListener("click", ()=>{
  const all = getLeitner();
  const rows = [["unit","nb","en","box","dueISO","timesSeen"], ...Object.entries(all).map(([k,v])=>{
    const [unit, ...nb] = k.split("|");
    return [unit, nb.join("|"), v.en||"", v.box, new Date(v.due).toISOString(), v.seen||0];
  })];
  const csv = rows.map(r=>r.map(x=>`"${String(x).replace(/"/g,'""')}"`).join(",")).join("\n");
  const url = URL.createObjectURL(new Blob([csv], {type:"text/csv"}));
  const a = Object.assign(document.createElement("a"), {href:url, download:"norskly_progress.csv"}); a.click(); URL.revokeObjectURL(url);
});

els.reviewAll.addEventListener("click", ()=>{
  const lessons = unitsForLevel();
  const all = getLeitner(), due=[];
  lessons.forEach(u=>u.cards.forEach(c=>{
    const box = all[keyFor(u.slug, c.nb)] || {due:0};
    if (Date.now() >= box.due) due.push({unit:u.slug, ...c});
  }));
  if (!due.length){ els.stage.innerHTML = "<div>No cards due. Pick a unit to learn new items.</div>"; return; }
  state.mode="flash";
  document.querySelector('[data-mode="flash"]').classList.add("bg-black","text-white");
  state.deck = shuffle(due);
  renderFlash();
});

els.voiceSelect.addEventListener("change", ()=>{
  settings.voice = els.voiceSelect.value;
  localStorage.setItem("norskly:voice", settings.voice);
});

els.preloadBtn.addEventListener("click", async ()=>{
  if (!state.currentUnit) return alert("Pick a unit first");
  const voice = settings.voice;
  els.preloadBtn.disabled = true; els.preloadBtn.textContent = "Preloading…";
  try {
    const r = await fetch("/api/preload", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ unit: state.currentUnit.slug, voice }) });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || "Failed");
    alert(`Preloaded ${j.count} audio files for ${state.currentUnit.name}`);
  } catch (e) {
    alert("Preload failed. Is the server running with OPENAI_API_KEY?");
  } finally {
    els.preloadBtn.disabled = false; els.preloadBtn.textContent = "Preload audio for this unit";
  }
});

function unitsForLevel(){ return (state.data.levels[state.level] || []).map(slug => state.data.units.find(u=>u.slug===slug)).filter(Boolean); }
function renderUnits(){
  const list = unitsForLevel();
  els.unitList.innerHTML = "";
  list.forEach(u=>{
    const node = document.createElement("button");
    node.className = "w-full text-left border rounded px-3 py-2 hover:bg-slate-50";
    node.innerHTML = `<div class="flex items-center justify-between"><div><div class="font-medium">${u.name}</div><div class="text-xs text-slate-500">${u.level} • ${u.cards.length} cards</div></div><span class="text-xs text-slate-500">${countDueForUnit(u.slug) || ""}</span></div>`;
    node.addEventListener("click", ()=> startUnit(u.slug));
    els.unitList.appendChild(node);
  });
}

// ---- Dashboard ----
function renderDashboard(){
  const allUnits = state.data.units.filter(u => (state.data.levels[state.level] || []).includes(u.slug));
  const store = getLeitner();
  const rows = allUnits.map(u=>{
    const total = u.cards.length;
    let seen=0, mastered=0, due=0;
    u.cards.forEach(c=>{
      const k = keyFor(u.slug, c.nb);
      const rec = store[k];
      if (rec){ seen++; if ((rec.box||1) >= 4) mastered++; if (Date.now() >= (rec.due||0)) due++; }
      else { due++; } // unseen counts as due for learning
    });
    const pct = total ? Math.round(mastered*100/total) : 0;
    return {slug:u.slug, name:u.name, total, seen, mastered, due, pct};
  }).sort((a,b)=>a.name.localeCompare(b.name));

  const cards = rows.map(r=>`
    <div class="border rounded-lg p-4">
      <div class="flex items-center justify-between">
        <div>
          <div class="font-semibold">${r.name}</div>
          <div class="text-xs text-slate-500">${r.seen}/${r.total} seen • ${r.mastered} mastered</div>
        </div>
        <div class="text-sm">${r.pct}%</div>
      </div>
      <div class="h-2 bg-slate-200 rounded mt-2">
        <div class="h-2 bg-green-500 rounded" style="width:${r.pct}%"></div>
      </div>
      <div class="flex items-center gap-3 mt-3 text-sm">
        <span class="text-slate-600">Due: <b>${r.due}</b></span>
        <button data-open="${r.slug}" class="openUnit px-2 py-1 border rounded">Open</button>
        <button data-preload="${r.slug}" class="preloadUnit px-2 py-1 border rounded">Preload audio</button>
      </div>
    </div>
  `).join("");

  els.stage.innerHTML = `
    <div class="space-y-4">
      <div class="flex items-center justify-between">
        <div>
          <div class="text-xl font-semibold">Dashboard — ${state.level}</div>
          <div class="text-slate-600 text-sm">Mastery is % of cards with Leitner box ≥ 4.</div>
        </div>
        <div class="text-sm">XP today: ${document.getElementById("xpToday").textContent} • Streak ${document.getElementById("streak").textContent}</div>
      </div>
      <div class="grid md:grid-cols-2 gap-4">${cards || "<div>No units found.</div>"}</div>
    </div>`;

  els.stage.querySelectorAll(".openUnit").forEach(b=> b.addEventListener("click", ()=>{
    const slug = b.getAttribute("data-open"); startUnit(slug);
  }));
  els.stage.querySelectorAll(".preloadUnit").forEach(b=> b.addEventListener("click", async ()=>{
    const slug = b.getAttribute("data-preload");
    const u = state.data.units.find(x=>x.slug===slug);
    if (!u) return;
    b.disabled=true; b.textContent="Preloading…";
    try{
      const r = await fetch("/api/preload", { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({ unit: slug, voice: settings.voice }) });
      const j = await r.json();
      if (!j.ok) throw new Error();
      alert(`Preloaded ${j.count} files for ${u.name}`);
    }catch{ alert("Preload failed"); }
    finally{ b.disabled=false; b.textContent="Preload audio"; }
  }));
}

// ---- Start unit + modes (same as v5)...
function startUnit(slug){
  state.currentUnit = state.data.units.find(u=>u.slug===slug);
  if (!state.currentUnit) return;
  if (state.mode==="flash") buildDeck(); 
  if (state.mode==="quiz") startQuiz();
  if (state.mode==="dialogue") renderDialogue();
  if (state.mode==="speak") renderSpeak();
  if (state.mode==="listen") renderListening();
  if (state.mode==="grammar") renderGrammar();
  if (state.mode==="reading") renderReading();
  if (state.mode==="writing") renderWriting();
  if (state.mode==="conjugate") renderConjugate();
}

// ---- Audio helpers
async function playAudio(text){
  try {
    const r = await fetch(`/api/tts?voice=${encodeURIComponent(settings.voice)}&lang=nb-NO&text=${encodeURIComponent(text)}`);
    const j = await r.json();
    if (j.ok && j.url){
      const audio = new Audio(j.url);
      await audio.play();
      return;
    }
  } catch {}
  try {
    const u = new SpeechSynthesisUtterance(text);
    const pick = speechSynthesis.getVoices().find(v => v.lang && v.lang.toLowerCase().startsWith("nb"));
    if (pick) u.voice = pick;
    u.lang = "nb-NO"; speechSynthesis.cancel(); speechSynthesis.speak(u);
  } catch {}
}

// ---- Flashcards & Leitner
function buildDeck(){
  const all = getLeitner(); const due=[], fresh=[];
  state.currentUnit.cards.forEach(c=>{
    const box = all[keyFor(state.currentUnit.slug, c.nb)] || {due:0};
    const item = {unit:state.currentUnit.slug, ...c};
    if (Date.now() >= box.due) due.push(item); else fresh.push(item);
  });
  state.deck = shuffle([...due, ...fresh]); renderFlash();
}
function renderFlash(){
  if (!state.deck.length){ els.stage.innerHTML = "<div>All done in this unit.</div>"; return; }
  const item = state.deck[0];
  els.stage.innerHTML = `
    <div class="space-y-4">
      <div class="text-sm text-slate-500">${countDueForUnit(state.currentUnit.slug)} due • ${state.currentUnit.name}</div>
      <div class="rounded-lg border p-6 text-center cursor-pointer select-none" id="card">
        <div class="text-2xl">${item.nb}</div>
        <div class="mt-2 text-slate-500 hidden" id="en">${item.en}</div>
      </div>
      <div class="flex gap-2">
        <button id="again" class="px-3 py-2 rounded border">Again</button>
        <button id="good" class="px-3 py-2 rounded bg-black text-white">Got it</button>
        <button id="reveal" class="px-3 py-2 rounded border ml-auto">Reveal</button>
        <button id="speak" class="px-3 py-2 rounded border">🔊</button>
      </div>
    </div>`;
  document.getElementById("card").addEventListener("click", ()=> playAudio(item.nb));
  document.getElementById("speak").addEventListener("click", ()=> playAudio(item.nb));
  document.getElementById("reveal").addEventListener("click", ()=> document.getElementById("en").classList.toggle("hidden"));
  document.getElementById("again").addEventListener("click", ()=> grade(item,false));
  document.getElementById("good").addEventListener("click", ()=> grade(item,true));
}
function grade(item, good){
  const all = getLeitner(); const k = keyFor(item.unit, item.nb);
  const rec = all[k] || {box:1, due:0, seen:0}; rec.seen = (rec.seen||0)+1;
  rec.box = good ? Math.min(6,(rec.box||1)+1) : 1;
  const days = {1:0,2:1,3:3,4:7,5:14,6:30}[rec.box]; rec.due = Date.now()+days*86400000; rec.en=item.en;
  all[k]=rec; setLeitner(all); addXP(XP_PER_CARD);
  state.deck.shift(); updateDueCount(); renderFlash();
}

// ---- Quiz
function startQuiz(){
  const items = shuffle(state.currentUnit.cards).slice(0, Math.min(10, state.currentUnit.cards.length));
  state.quiz = {items, idx:0, score:0}; renderQuiz();
}
function renderQuiz(){
  const q = state.quiz;
  if (q.idx >= q.items.length){
    addXP(Math.round(q.score*XP_PER_QUIZ));
    els.stage.innerHTML = `<div class="space-y-2"><div class="text-xl">Score: ${q.score}/${q.items.length}</div><button id="retry" class="border rounded px-3 py-2">Retry</button></div>`;
    document.getElementById("retry").addEventListener("click", startQuiz); return;
  }
  const item = q.items[q.idx];
  const opts = new Set([item.en]); while (opts.size<4){ opts.add(randomFrom(state.currentUnit.cards).en); }
  els.stage.innerHTML = `
    <div class="space-y-4">
      <div class="text-sm text-slate-500">Question ${q.idx+1} of ${q.items.length}</div>
      <div class="rounded-lg border p-6 text-xl">${item.nb}</div>
      <div class="grid gap-2" id="answers"></div>
    </div>`;
  Array.from(opts).sort(()=>Math.random()-0.5).forEach(ans=>{
    const b = Object.assign(document.createElement("button"), {className:"px-3 py-2 rounded border text-left", textContent: ans});
    b.addEventListener("click", ()=>{ if(ans===item.en){ q.score++; b.classList.add("bg-green-50"); } else { b.classList.add("bg-red-50"); } setTimeout(()=>{ q.idx++; renderQuiz(); }, 400); });
    document.getElementById("answers").appendChild(b);
  });
}

// ---- Dialogues
function renderDialogue(){
  const box = document.createElement("div"); box.className="space-y-2";
  (state.currentUnit.dialogue||[]).forEach(line=>{
    const div = document.createElement("div");
    div.className="p-3 border rounded"; 
    div.innerHTML = `<div class="text-sm text-slate-500">${line.speaker||""}</div><div class="text-lg">${line.nb}</div><div class="text-slate-500">${line.en}</div>`;
    div.addEventListener("click", ()=> playAudio(line.nb)); box.appendChild(div);
  });
  els.stage.innerHTML=""; els.stage.appendChild(box);
}

// ---- Speak
function renderSpeak(){
  const cards = state.currentUnit.cards;
  const item = cards[state.speakIdx % cards.length];
  els.stage.innerHTML = `
    <div class="space-y-4">
      <div class="text-sm text-slate-500">Say it in Norwegian. Click mic.</div>
      <div class="rounded-lg border p-6">
        <div class="text-2xl">${item.nb}</div>
        <div class="text-slate-500">${item.en}</div>
      </div>
      <div class="flex items-center gap-2">
        <button id="mic" class="px-3 py-2 rounded border">🎤 Start</button>
        <div id="status" class="text-sm text-slate-600"></div>
        <button id="next" class="px-3 py-2 rounded border ml-auto">Next</button>
        <button id="play" class="px-3 py-2 rounded border">🔊</button>
      </div>
      <div id="result" class="text-sm"></div>
    </div>`;
  document.getElementById("play").addEventListener("click", ()=> playAudio(item.nb));
  document.getElementById("next").addEventListener("click", ()=>{ state.speakIdx++; renderSpeak(); });
  document.getElementById("mic").addEventListener("click", ()=>{
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR){ alert("Speech recognition not supported in this browser. Try Chrome."); return; }
    const r = new SR(); r.lang="nb-NO"; r.maxAlternatives=1;
    document.getElementById("status").textContent="Listening…"; document.getElementById("result").textContent="";
    r.start();
    r.onresult = e => {
      const said = e.results[0][0].transcript;
      const pct = Math.round(similarity(normalize(item.nb), normalize(said))*100);
      document.getElementById("status").textContent = "Heard: " + said;
      if (pct>=90){ document.getElementById("result").innerHTML=`<span class="text-green-700">Great! ${pct}%</span>`; addXP(3); }
      else if (pct>=70){ document.getElementById("result").innerHTML=`<span class="text-yellow-700">Close (${pct}%). Try again.</span>`; }
      else { document.getElementById("result").innerHTML=`<span class="text-red-700">${pct}% — listen and repeat.</span>`; }
    };
    r.onerror = e => document.getElementById("status").textContent = "Error: " + e.error;
  });
}

// ---- Listening
function renderListening(){
  const passage = randomFrom(state.currentUnit.readings || [{nb:"Lytt: Jeg liker å lære norsk hver dag.", en:"Listen: I like to learn Norwegian every day."}]);
  const q = passage.q || {text:"What is the main topic?", options:["Learning Norwegian","Shopping","Football","Weather"], answer:0};
  els.stage.innerHTML = `
    <div class="space-y-4">
      <div class="text-sm text-slate-500">Press play and listen. Then answer.</div>
      <div class="rounded border p-4">${passage.nb}</div>
      <div class="flex gap-2"><button id="play" class="px-3 py-2 rounded border">▶️ Play</button></div>
      <div class="mt-2 text-sm">${q.text}</div>
      <div id="answers" class="grid gap-2"></div>
    </div>`;
  document.getElementById("play").addEventListener("click", ()=> playAudio(passage.nb));
  q.options.forEach((opt, i)=>{
    const b = Object.assign(document.createElement("button"), {className:"px-3 py-2 border rounded text-left", textContent:opt});
    b.addEventListener("click", ()=>{
      if (i===q.answer){ b.classList.add("bg-green-50"); addXP(XP_PER_LISTEN); } else { b.classList.add("bg-red-50"); }
    });
    document.getElementById("answers").appendChild(b);
  });
}

// ---- Grammar
function renderGrammar(){
  const g = state.currentUnit.grammar;
  const examples = (g?.examples||[]).map(s=>`<li><span class="font-medium">${s.nb}</span> — <span class="text-slate-600">${s.en}</span></li>`).join("");
  els.stage.innerHTML = `
    <div class="space-y-3">
      <div class="text-xl font-semibold">${g?.title || "Grammar"}</div>
      <div class="text-slate-700">${g?.body || "No tips yet."}</div>
      <div class="mt-2 text-sm text-slate-500">Examples</div>
      <ul class="list-disc pl-6">${examples}</ul>
    </div>`;
}

// ---- Reading
function renderReading(){
  const r = randomFrom(state.currentUnit.readings || []);
  if (!r){ els.stage.innerHTML="<div>No reading passages yet.</div>"; return; }
  els.stage.innerHTML = `
    <div class="space-y-3">
      <div class="text-sm text-slate-500">${state.currentUnit.name} • ${state.currentUnit.level}</div>
      <div class="text-lg">${r.nb}</div>
      <div class="text-slate-600">${r.en}</div>
      <button id="play" class="px-3 py-2 rounded border">🔊 Listen</button>
      <div class="mt-3">${r.q.text}</div>
      <div id="answers" class="grid gap-2"></div>
    </div>`;
  document.getElementById("play").addEventListener("click", ()=> playAudio(r.nb));
  r.q.options.forEach((opt,i)=>{
    const b = Object.assign(document.createElement("button"), {className:"px-3 py-2 border rounded text-left", textContent:opt});
    b.addEventListener("click", ()=>{
      if (i===r.q.answer){ b.classList.add("bg-green-50"); addXP(3); } else { b.classList.add("bg-red-50"); }
    });
    document.getElementById("answers").appendChild(b);
  });
}

// ---- Writing
function renderWriting(){
  const w = randomFrom(state.currentUnit.writing || []);
  if (!w){ els.stage.innerHTML="<div>No writing prompts yet.</div>"; return; }
  els.stage.innerHTML = `
    <div class="space-y-3">
      <div class="text-xl font-semibold">${w.title}</div>
      <div class="text-slate-700">${w.prompt}</div>
      <textarea id="draft" class="w-full border rounded p-3 min-h-[140px]" placeholder="Write in Norwegian here…"></textarea>
      <div class="text-sm text-slate-500">Checklist</div>
      <ul class="list-disc pl-6">${w.checklist.map(x=>`<li>${x}</li>`).join("")}</ul>
      <details class="mt-2"><summary class="cursor-pointer text-sm text-slate-600">Show sample answer</summary><div class="p-3 border rounded mt-2">${w.sample}</div></details>
      <button id="markDone" class="px-3 py-2 rounded bg-black text-white">Mark as practiced</button>
    </div>`;
  document.getElementById("markDone").addEventListener("click", ()=>{ addXP(XP_PER_WRITE); alert("Nice! +XP added."); });
}

// ---- Conjugation
function renderConjugate(){
  const v = randomFrom(state.currentUnit.verbs || state.data.verbpack || []);
  const forms = v.forms;
  els.stage.innerHTML = `
    <div class="space-y-3">
      <div class="text-xl font-semibold">${v.inf} — ${v.en}</div>
      <div class="grid md:grid-cols-2 gap-2">
        <div class="p-3 border rounded"><div class="text-sm text-slate-500">Present</div><div>${forms.present}</div></div>
        <div class="p-3 border rounded"><div class="text-sm text-slate-500">Past</div><div>${forms.past}</div></div>
        <div class="p-3 border rounded"><div class="text-sm text-slate-500">Present perfect</div><div>${forms.perfektum}</div></div>
        <div class="p-3 border rounded"><div class="text-sm text-slate-500">Infinitive</div><div>å ${v.inf}</div></div>
      </div>
      <div class="mt-2 text-sm">Fill the blank:</div>
      <div class="p-3 border rounded">${v.drill.q}</div>
      <input id="ans" class="border rounded px-3 py-2" placeholder="Type the correct form"/>
      <button id="check" class="px-3 py-2 rounded border">Check</button>
      <div id="res" class="text-sm"></div>
    </div>`;
  document.getElementById("check").addEventListener("click", ()=>{
    const a = document.getElementById("ans").value.trim().toLowerCase();
    const ok = v.drill.a.toLowerCase();
    if (a === ok){ document.getElementById("res").innerHTML = "<span class='text-green-700'>Correct!</span>"; addXP(2); }
    else { document.getElementById("res").innerHTML = `<span class='text-red-700'>${a || "(blank)"} — correct: ${v.drill.a}</span>`; }
  });
}

// ---- Utils & XP
function normalize(s){ return s.toLowerCase().replace(/[^a-zæøåàáäéèëìíïòóöùúüœ\s]/gi,"").replace(/\s+/g," ").trim(); }
function similarity(a,b){
  const m=new Map(), al=a.length, bl=b.length;
  for(let i=0;i<=al;i++) m.set(i+",0", i);
  for(let j=0;j<=bl;j++) m.set("0,"+j, j);
  for(let i=1;i<=al;i++) for(let j=1;j<=bl;j++){
    const cost = a[i-1]===b[j-1]?0:1;
    m.set(i+","+j, Math.min(m.get((i-1)+","+j)+1, m.get(i+","+(j-1))+1, m.get((i-1)+","+(j-1))+cost));
  }
  const dist = m.get(al+","+bl); return 1 - dist/Math.max(1,al,bl);
}
function keyFor(unit, nb){ return `${unit}|${nb}`; }
function getLeitner(){ return JSON.parse(localStorage.getItem("norskly:leitner") || "{}"); }
function setLeitner(v){ localStorage.setItem("norskly:leitner", JSON.stringify(v)); }
function countDueForUnit(slug){
  const all=getLeitner(); const u=(state.data.units.find(x=>x.slug===slug)||{cards:[]});
  let n=0; u.cards.forEach(c=>{ const box=all[keyFor(slug,c.nb)]||{due:0}; if(Date.now()>=box.due) n++; }); return n;
}
function randomFrom(a){ return a[Math.floor(Math.random()*a.length)]; }
function shuffle(a){ for (let i=a.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [a[i],a[j]]=[a[j],a[i]]; } return a; }
function stats(){ return JSON.parse(localStorage.getItem("norskly:stats") || "{}"); }
function saveStats(s){ localStorage.setItem("norskly:stats", JSON.stringify(s)); }
function addXP(x){
  const s = stats(); const today = new Date().toISOString().slice(0,10);
  if (!s.days) s.days={}; if (!s.days[today]) s.days[today]={xp:0};
  s.days[today].xp += x; saveStats(s); updateXP();
}
function updateXP(){
  const goal = parseInt(document.getElementById("goalSelect").value,10);
  const s = stats(); const today = new Date().toISOString().slice(0,10);
  const xp = (s.days && s.days[today] && s.days[today].xp) || 0;
  document.getElementById("xpToday").textContent = `${xp} / ${goal} XP`;
  let streak = s.streak||0; let last = s.lastDay || null;
  if (last !== today){
    const yday = new Date(Date.now()-86400000).toISOString().slice(0,10);
    if (xp>0){
      streak = (last===yday) ? (streak||0)+1 : 1;
      s.streak = streak; s.lastDay = today; saveStats(s);
    }
  }
  document.getElementById("streak").textContent = "🔥 " + (s.streak||0);
}
document.getElementById("goalSelect").addEventListener("change", updateXP);
